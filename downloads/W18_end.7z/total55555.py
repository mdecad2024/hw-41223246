# pip install pyzmq cbor keyboard
from coppeliasim_zmqremoteapi_client import RemoteAPIClient
import keyboard

# Connecting to the CoppeliaSim server
client = RemoteAPIClient('localhost', 23000)

print('Program started')
sim = client.getObject('sim')

# Get the handle for the joints and slider
cw = sim.getObject('/cw_joint')
ccw = sim.getObject('/ccw_joint')
slider = sim.getObject('/Prismatic_joint')

# Starting the simulation
sim.startSimulation()
print('Simulation started')

# Main control loop
def main():
    # Keep running until simulation is stopped
    while True:
        # Control cw_joint
        if keyboard.is_pressed('p'):
            print("p is pressed")
            sim.setJointTargetPosition(cw, -0.25)
        
        if keyboard.is_pressed('l'):
            print("l is pressed")
            sim.setJointTargetPosition(cw, 0.0)  # Reset to the initial position
        
        # Control ccw_joint
        if keyboard.is_pressed('w'):
            print("w is pressed")
            sim.setJointTargetPosition(ccw, -0.28)
        
        if keyboard.is_pressed('s'):
            print("s is pressed")
            sim.setJointTargetPosition(ccw, 0.0)  # Reset to the initial position
        
        # Control slider
        if keyboard.is_pressed('a'):
            print("a is pressed")
            sim.setJointTargetPosition(slider, -0.15)
        
        if keyboard.is_pressed('d'):
            print("d is pressed")
            sim.setJointTargetPosition(slider, 0.0)  # Reset to the initial position

        # Stop the simulation
        if keyboard.is_pressed('q'):
            print("q is pressed - stopping simulation")
            sim.stopSimulation()
            break

# Start the main control loop
main()
